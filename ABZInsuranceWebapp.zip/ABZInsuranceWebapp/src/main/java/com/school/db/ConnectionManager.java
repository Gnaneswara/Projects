package com.school.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.school.bean.UserBean;
import com.school.daoImpl.UserDAOImpl;

public class ConnectionManager {
	static Logger logger=Logger.getLogger(UserDAOImpl.class); //in class

	public static Connection con = null;
	public static Connection getConnection()
	{

		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/insurance","root","root");
		} catch (ClassNotFoundException e) {
			logger.info("ConnecrionManager ClassNotFoundException");       //in method

			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.info("ConnecrionManager SQLException");       //in method

			e.printStackTrace();
		}
		UserBean u=new UserBean();
		logger.info(u.type+" type try to connect to the database ");  //in method
		return con;
		
	}

}
