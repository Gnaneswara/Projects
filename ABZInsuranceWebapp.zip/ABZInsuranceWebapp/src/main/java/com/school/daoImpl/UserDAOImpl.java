package com.school.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.school.bean.UserBean;
import com.school.dao.UserDAO;
import com.school.db.ConnectionManager;

public class UserDAOImpl implements UserDAO {
	static Logger logger=Logger.getLogger(UserDAOImpl.class);
    public int login(UserBean u) {
		int type=0;
		int userId=0;
		try {
			Connection con = ConnectionManager.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from `insurance`.`users` where first_name=? AND password=?");
			ps.setString(1, u.getUserName());
			ps.setString(2, u.getPassWord());
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				type=rs.getInt(5);
				userId=rs.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.info("UserDAOImpl SQLException");
			e.printStackTrace();
			
		}
		logger.info("User Type try to login into the application:"+type);
		return type;
	}

	public String forgot(UserBean u) {
		
		String password=null;
		try {
			Connection con = ConnectionManager.getConnection();
			PreparedStatement ps = con.prepareStatement("select password from `insurance`.`users` where first_name=? AND question =? AND answer=?");
            ps.setString(1, u.getUserName());
			ps.setString(2, u.getQuestion());
			ps.setString(3, u.getAnswer());
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				password=rs.getString(1);
			System.out.println("password---->"+password);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.info("UserDAOImpl SQLException");
			e.printStackTrace();
		}
		logger.info("User Type Forgot Password in the application:"+u.getUserName());

		return password;
	}
	public String AddUsers(UserBean u)
	{
		

		String status="";
		Connection con = ConnectionManager.getConnection();
		try {
			PreparedStatement ps = con.prepareStatement("insert into insurance.users(first_name,email,password,role_id,mobile_number,address,question,answer) values (?,?,?,2,?,?,?,?)");
		ps.setString(1, u.getUserName());
		ps.setString(2, u.getEmailId());
		ps.setString(3, u.getPassWord());
		ps.setLong(4, u.getMobileNo());
		ps.setString(5, u.getAddress());
		ps.setString(6, u.getQuestion());
		ps.setString(7, u.getAnswer());
		int i=ps.executeUpdate();
		if(i==1)
		{ status="Success";}
		else
		{status="no Success";}
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.info("UserDAOImpl SQLException");

			e.printStackTrace();
		}
		logger.info("Admin Type try to Add New User "+u.getUserName());
		return status;
		
	}
	public ArrayList<UserBean> ViewallUsers() {
		
		Connection con = ConnectionManager.getConnection();
		ArrayList<UserBean> al=new ArrayList<UserBean>();
		try {
			PreparedStatement ps=con.prepareStatement("SELECT * FROM `insurance`.`users`");
			
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				UserBean ub=new UserBean();
			ub.setUserId(rs.getInt(1));
			ub.setUserName(rs.getString(2));
			al.add(ub);
				}
			System.out.println("---------------"+al);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.info("UserDAOImpl SQLException");

			e.printStackTrace();
		}
		logger.info("Admin Type try  to ViewAll Users in the application");
		return al;
	}

	public String fogot(UserBean u) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
