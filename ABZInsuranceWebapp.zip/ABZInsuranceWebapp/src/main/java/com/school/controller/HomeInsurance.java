package com.school.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.school.bean.UserBean;
import com.school.daoImpl.UserDAOImpl;
import com.school.db.ConnectionManager;

/**
 * Servlet implementation class HomeInsurance
 */
public class HomeInsurance extends HttpServlet {
	static Logger logger=Logger.getLogger(UserDAOImpl.class); //in class

	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HomeInsurance() {
        super();
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	doPost(request,response);
    }
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//System.out.println("in post");
		response.setContentType("text/html");
		double load=0;
		double loadOnPremium=0;
		Connection con = ConnectionManager.getConnection();
		int home=Integer.parseInt(request.getParameter("homeType"));
		int termFactor=Integer.parseInt(request.getParameter("TermFactor"));
		double price=Double.parseDouble(request.getParameter("price"));
		double basePremiumOfHome=price*0.2;
		double totalPremium=basePremiumOfHome+loadOnPremium;
		if (home == 3) {
		//	System.out.println("---ifhome==3-----");
			if (termFactor == 1) {
				//System.out.println("---ifhome==3 and termfactor==2-----");
				loadOnPremium = basePremiumOfHome * (load / 100);
				
				totalPremium = basePremiumOfHome
						+ (price * (0.2) * (0.15)) + loadOnPremium;
				try {
					PreparedStatement ps = con.prepareStatement("insert into insurance.all_insurance(insurance_id,type_id,years,cost,date,status,user_id) values(2,?,?,?,curdate(),'active',?)" );
					ps.setInt(1,Integer.parseInt(request.getParameter("homeType")));
					ps.setInt(2, Integer.parseInt(request.getParameter("TermFactor")));
					ps.setDouble(3,Double.parseDouble(request.getParameter("price")));
					ps.setInt(4, Integer.parseInt(request.getParameter("uid")));
					int i = ps.executeUpdate();

					if (i == 1) {
						request.setAttribute("message", "Insurance Added Succesfully.Your Premium Is "+totalPremium+"");
						RequestDispatcher rd=request.getRequestDispatcher("HomeInsurance.jsp");
						rd.forward(request, response);
					} else {
						request.setAttribute("message", "Failed To Add Insurance");
						RequestDispatcher rd=request.getRequestDispatcher("HomeInsurance.jsp");
						rd.forward(request, response);
					}

				} catch (SQLException e) {
					logger.info("UserDAOImpl SQLException");       //in method

					e.printStackTrace();
				}

			} else if (termFactor == 2) {
				//System.out.println("---ifhome==3 and termfactor==2-----");
				load = 0.4;
				loadOnPremium = basePremiumOfHome * (load / 100);
				
				totalPremium = basePremiumOfHome
						+ (price * (0.2) * (0.15) + loadOnPremium);
	

				try {
					PreparedStatement ps = con.prepareStatement("insert into insurance.all_insurance(insurance_id,type_id,years,cost,date,status,user_id) values(2,?,?,?,curdate(),'active',?)" );
					ps.setInt(1,Integer.parseInt(request.getParameter("homeType")));
					ps.setInt(2, Integer.parseInt(request.getParameter("TermFactor")));
					ps.setDouble(3,Double.parseDouble(request.getParameter("price")));
					ps.setInt(4, Integer.parseInt(request.getParameter("uid")));
					int i = ps.executeUpdate();

					if (i == 2) {
						request.setAttribute("message", "Insurance Added Succesfully.Your Premium Is "+totalPremium+"");
						RequestDispatcher rd=request.getRequestDispatcher("HomeInsurance.jsp");
						rd.forward(request, response);
					} else {
						request.setAttribute("message", "Failed To Add Insurance");
						RequestDispatcher rd=request.getRequestDispatcher("HomeInsurance.jsp");
						rd.forward(request, response);
					}

				} catch (SQLException e) {
					logger.info("UserDAOImpl SQLException");       //in method

					e.printStackTrace();
				}


	}

		}
		else if (home == 4) {
			//System.out.println("---ifhome==2-----");
			if (termFactor == 1) {
				//System.out.println("---ifhome==4 and termfactor==1-----");
				loadOnPremium = basePremiumOfHome * (load / 100);
				basePremiumOfHome = price * (0.2);
				totalPremium = basePremiumOfHome
						+ (price * (0.2) * (0.15)) + loadOnPremium;

				try {
					PreparedStatement ps = con.prepareStatement("insert into insurance.all_insurance(insurance_id,type_id,years,cost,date,status,user_id) values(2,?,?,?,curdate(),'active',?)" );
					ps.setInt(1,Integer.parseInt(request.getParameter("homeType")));
					ps.setInt(2, Integer.parseInt(request.getParameter("TermFactor")));
					ps.setDouble(3,Double.parseDouble(request.getParameter("price")));
					ps.setInt(4, Integer.parseInt(request.getParameter("uid")));
					int i = ps.executeUpdate();

					if (i == 1) {
						request.setAttribute("message", "Insurance Added Succesfully.Your Premium Is "+totalPremium+"");
						RequestDispatcher rd=request.getRequestDispatcher("HomeInsurance.jsp");
						rd.forward(request, response);
					} else {
						request.setAttribute("message", "Failed To Add Insurance");
						RequestDispatcher rd=request.getRequestDispatcher("HomeInsurance.jsp");
						rd.forward(request, response);
					}


				} catch (SQLException e) {
					logger.info("UserDAOImpl SQLException");       //in method

					e.printStackTrace();
				}
			} else if (termFactor == 2) {
				//System.out.println("---ifhome==4 and termfactor==2-----");
				load = 0.4;
				basePremiumOfHome = price * (0.2);
				
				loadOnPremium = basePremiumOfHome * (load / 100);
				totalPremium = basePremiumOfHome
						+ (price * (0.2) * (0.15)) + loadOnPremium;
				try {
					PreparedStatement ps = con.prepareStatement("insert into insurance.all_insurance(insurance_id,type_id,years,cost,date,status,user_id) values(2,?,?,?,curdate(),'active',?)" );
					ps.setInt(1,Integer.parseInt(request.getParameter("homeType")));
					ps.setInt(2, Integer.parseInt(request.getParameter("TermFactor")));
					ps.setDouble(3,Double.parseDouble(request.getParameter("price")));
					ps.setInt(4, Integer.parseInt(request.getParameter("uid")));
					int i = ps.executeUpdate();

					if (i == 1) {
						request.setAttribute("message", "Insurance Added Succesfully.Your Premium Is "+totalPremium+"");
						RequestDispatcher rd=request.getRequestDispatcher("HomeInsurance.jsp");
						rd.forward(request, response);
					} else {
						request.setAttribute("message", "Failed To Add Insurance");
						RequestDispatcher rd=request.getRequestDispatcher("HomeInsurance.jsp");
						rd.forward(request, response);
					}

				} catch (SQLException e) {
					logger.info("UserDAOImpl SQLException");       //in method

					e.printStackTrace();
				}

			}
			}
		UserBean u=new UserBean();
		logger.info("User type try to add Home Insurance in the application:"+u.getUserName());  //in method
}
	
}
