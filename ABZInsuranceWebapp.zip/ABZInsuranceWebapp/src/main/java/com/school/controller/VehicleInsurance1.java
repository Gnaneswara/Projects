package com.school.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLDataException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.school.bean.UserBean;
import com.school.daoImpl.UserDAOImpl;
import com.school.db.ConnectionManager;

/**
 * Servlet implementation class VehicleInsurance1
 */
public class VehicleInsurance1 extends HttpServlet {
	static Logger logger=Logger.getLogger(UserDAOImpl.class); //in class

	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public VehicleInsurance1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		double load=0;
		double loadOnPremium=0;
		Connection con = ConnectionManager.getConnection();
		int vehicle=Integer.parseInt(request.getParameter("vehicleType"));
		int termFactor=Integer.parseInt(request.getParameter("TermFactor"));
		double price=Double.parseDouble(request.getParameter("price"));
		double basePremiumOfVehicle=price*0.2;
		double totalPremium=basePremiumOfVehicle+loadOnPremium;
		if (vehicle == 1) {
			if (termFactor == 1) {
				
				loadOnPremium = basePremiumOfVehicle * (load / 100);
				
				totalPremium = basePremiumOfVehicle
						+ (price * (0.2) * (0.15)) + loadOnPremium;
				try {
					PreparedStatement ps = con.prepareStatement("insert into insurance.all_insurance(insurance_id,type_id,years,cost,date,status,user_id) values(1,?,?,?,curdate(),'active',?)" );
					ps.setInt(1,Integer.parseInt(request.getParameter("vehicleType")));
					ps.setInt(2, Integer.parseInt(request.getParameter("TermFactor")));
					ps.setDouble(3,Double.parseDouble(request.getParameter("price")));
					ps.setInt(4, Integer.parseInt(request.getParameter("uid")));
					int i = ps.executeUpdate();

					if (i == 1) {
						request.setAttribute("message", "Insurance Added Succesfully.Your Premium Is "+totalPremium+"");
						RequestDispatcher rd=request.getRequestDispatcher("VehicleInsurance.jsp");
						rd.forward(request, response);
					} else {
						request.setAttribute("message", "Failed To Add Insurance");
						RequestDispatcher rd=request.getRequestDispatcher("VehicleInsurance.jsp");
						rd.forward(request, response);
					}

				} catch (SQLException e) {
					logger.info("UserDAOImpl SQLException");       //in method

					e.printStackTrace();
				}

			} else if (termFactor == 2) {
				load = 0.4;
				loadOnPremium = basePremiumOfVehicle * (load / 100);
				
				totalPremium = basePremiumOfVehicle
						+ (price * (0.2) * (0.15) + loadOnPremium);

				try {
					PreparedStatement ps = con.prepareStatement("insert into insurance.all_insurance(insurance_id,type_id,years,cost,date,status,user_id) values(1,?,?,?,curdate(),'active',?)" );
					ps.setInt(1,Integer.parseInt(request.getParameter("vehicleType")));
					ps.setInt(2, Integer.parseInt(request.getParameter("TermFactor")));
					ps.setDouble(3,Double.parseDouble(request.getParameter("price")));
					ps.setInt(4, Integer.parseInt(request.getParameter("uid")));
					int i = ps.executeUpdate();

					if (i == 1) {
						request.setAttribute("message", "Insurance Added Succesfully.Your Premium Is "+totalPremium+"");
						RequestDispatcher rd=request.getRequestDispatcher("VehicleInsurance.jsp");
						rd.forward(request, response);
					} else {
						request.setAttribute("message", "Failed To Add Insurance");
						RequestDispatcher rd=request.getRequestDispatcher("VehicleInsurance.jsp");
						rd.forward(request, response);
					}

				} catch (SQLException e) {
					logger.info("UserDAOImpl SQLException");       //in method

					e.printStackTrace();
				}

			} 

		}

		else if (vehicle == 2) {
			if (termFactor == 1) {
				loadOnPremium = basePremiumOfVehicle * (load / 100);
				basePremiumOfVehicle = price * (0.2);
				totalPremium = basePremiumOfVehicle
						+ (price * (0.2) * (0.15)) + loadOnPremium;

				try {
					PreparedStatement ps = con.prepareStatement("insert into insurance.all_insurance(insurance_id,type_id,years,cost,date,status,user_id) values(1,?,?,?,curdate(),'active',?)" );
					ps.setInt(1,Integer.parseInt(request.getParameter("vehicleType")));
					ps.setInt(2, Integer.parseInt(request.getParameter("TermFactor")));
					ps.setDouble(3,Double.parseDouble(request.getParameter("price")));
					ps.setInt(4, Integer.parseInt(request.getParameter("uid")));
					int i = ps.executeUpdate();

					if (i == 1) {
						request.setAttribute("message", "Insurance Added Succesfully.Your Premium Is "+totalPremium+"");
						RequestDispatcher rd=request.getRequestDispatcher("VehicleInsurance.jsp");
						rd.forward(request, response);
					} else {
						request.setAttribute("message", "Failed To Add Insurance");
						RequestDispatcher rd=request.getRequestDispatcher("VehicleInsurance.jsp");
						rd.forward(request, response);
					}


				} catch (SQLException e) {
					logger.info("UserDAOImpl SQLException");       //in method

					e.printStackTrace();
				}
			} else if (termFactor == 2) {
				load = 0.4;
				basePremiumOfVehicle = price * (0.2);
				
				loadOnPremium = basePremiumOfVehicle * (load / 100);
				totalPremium = basePremiumOfVehicle
						+ (price * (0.2) * (0.15)) + loadOnPremium;
				try {
					PreparedStatement ps = con.prepareStatement("insert into insurance.all_insurance(insurance_id,type_id,years,cost,date,status,user_id) values(1,?,?,?,curdate(),'active',?)" );
					ps.setInt(1,Integer.parseInt(request.getParameter("vehicleType")));
					ps.setInt(2, Integer.parseInt(request.getParameter("TermFactor")));
					ps.setDouble(3,Double.parseDouble(request.getParameter("price")));
					ps.setInt(4, Integer.parseInt(request.getParameter("uid")));
					int i = ps.executeUpdate();

					if (i == 1) {
						request.setAttribute("message", "Insurance Added Succesfully.Your Premium Is "+totalPremium+"");
						RequestDispatcher rd=request.getRequestDispatcher("VehicleInsurance.jsp");
						rd.forward(request, response);
					} else {
						request.setAttribute("message", "Failed To Add Insurance");
						RequestDispatcher rd=request.getRequestDispatcher("VehicleInsurance.jsp");
						rd.forward(request, response);
					}

				} catch (SQLDataException e) {
					logger.info("UserDAOImpl SQLException");       //in method

					e.printStackTrace();
				} catch (NumberFormatException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

		


	}UserBean u=new UserBean();
		logger.info("User type try to add Vehicle Insurance in the application:"+u.getUserName());  //in method
	}
	}


