package com.school.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.school.bean.UserBean;
import com.school.daoImpl.UserDAOImpl;

/**
 * Servlet implementation class ForgotPassWord
 */
public class ForgotPassWord extends HttpServlet {
	static Logger logger=Logger.getLogger(UserDAOImpl.class); //in class

	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ForgotPassWord() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		UserBean u = new UserBean();
		UserDAOImpl userDAO = new UserDAOImpl();
		u.setUserName(request.getParameter("uname"));
		u.setQuestion(request.getParameter("question"));
		u.setAnswer(request.getParameter("answer"));
		u.setEmailId(request.getParameter("email"));
		String pass = userDAO.forgot(u);
		System.out.println("password====."+pass);
		if(pass!=null)
		{
			//u.setPassword(pass);
			pw.println("your password is .."+pass);
			RequestDispatcher rd=request.getRequestDispatcher("signin.html");
			rd.include(request, response);
			
			
			u.setPassWord(pass);
			//String to=u.getEmail();//change accordingly to mail id
					String to = u.getEmailId();
			        System.out.println(u.getEmailId());
					//Get the session object
					  Properties props = new Properties();
					  props.put("mail.smtp.host", "smtp.gmail.com");
					  props.put("mail.smtp.socketFactory.port", "465");
					  props.put("mail.smtp.socketFactory.class",
					        	"javax.net.ssl.SSLSocketFactory");
					  props.put("mail.smtp.auth", "true");
					  props.put("mail.smtp.port", "465");
					 
					  Session session = Session.getDefaultInstance(props,
					   new javax.mail.Authenticator() {
					   protected PasswordAuthentication getPasswordAuthentication() {
					   return new PasswordAuthentication("javatraining.biji@gmail.com","sudaksha4$");//change accordingly
					   }
					  });
					 
					//compose message
					  try {
					   MimeMessage message = new MimeMessage(session);
					   message.setFrom(new InternetAddress("javatraining.biji@gmail.com"));//change accordingly
					   message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));
					   message.setSubject("Regarding Forgot Password");
					   message.setText("Hi '"+u.getUserName()+"'.......your requested password is    "+pass+"<br/> and your mobile number '"+u.getMobileNo()+"'Please contact customer care service @ Chandu ");
					   
					   
					   //send message
					   Transport.send(message);

					   pw.println("<center><h3>message sent successfully<h3></center>");
					   pw.println("<br>");
					   pw.println("<a href=http://localhost:8087/ABZInsurance/signin.html>Open Login Page</a>");
					 
					  } catch (MessagingException e) {throw new RuntimeException(e);}

					
		}
		else
		{
			pw.println("Sorry data didn't match....try again");
			RequestDispatcher rd=request.getRequestDispatcher("forgot.html");
			rd.include(request, response);
			
		}logger.info("User type Forgot Password in the application:"+u.getUserName());  //in method
	}

}
