package com.school.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.school.bean.UserBean;
import com.school.daoImpl.UserDAOImpl;

/**
 * Servlet implementation class UserController
 */
public class UserController extends HttpServlet {
	static Logger logger=Logger.getLogger(UserDAOImpl.class); //in class

	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		UserBean u = new UserBean();
		UserDAOImpl userDAO = new UserDAOImpl();
	
		u.setUserName(request.getParameter("uname"));
		u.setPassWord(request.getParameter("pass"));
		int type = userDAO.login(u);
		int userId = userDAO.login(u);
		HttpSession session=request.getSession(true);
		session.setAttribute("uid", userId);
		if(type==0)
		{
			out.println("Please Enter Valid User Name / Password");
			RequestDispatcher rd = request.getRequestDispatcher("signin.jsp");
			rd.include(request, response);
		}else if(type==1){
			RequestDispatcher rd = request.getRequestDispatcher("AdminHome.jsp");
			rd.forward(request, response);
		}else if(type==2){
			RequestDispatcher rd = request.getRequestDispatcher("UserHome.jsp");
			rd.forward(request, response);
		}
		logger.info(u.type+" type try to login into the application:"+u.getUserName());  //in method
	}

}
