package com.school.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.school.bean.UserBean;
import com.school.daoImpl.UserDAOImpl;

/**
 * Servlet implementation class ViewAllUsers
 */
public class ViewAllUsers extends HttpServlet {
	static Logger logger=Logger.getLogger(UserDAOImpl.class); //in class

	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ViewAllUsers() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		UserDAOImpl ud=new UserDAOImpl();
		ud.ViewallUsers();
		ArrayList<UserBean> ul=ud.ViewallUsers();
		if(ul!=null)
		{ 
			//System.out.println("list not empty");
			request.setAttribute("userlist", ul);
	    RequestDispatcher rd=request.getRequestDispatcher("ViewAll.jsp");
	    rd.forward(request, response);
	}else{
		//System.out.println("list empty");
	    request.setAttribute("userlist", ul);
	    RequestDispatcher rd=request.getRequestDispatcher("AdminHome.jsp");
	    rd.forward(request, response);
	    
	}
		UserBean u=new UserBean();
		logger.info("User type message in the application:"+u.getUserName());  //in method
}}
