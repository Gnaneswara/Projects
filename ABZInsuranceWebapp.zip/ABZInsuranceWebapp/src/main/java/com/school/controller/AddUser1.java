package com.school.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.school.bean.UserBean;
import com.school.daoImpl.UserDAOImpl;

/**
 * Servlet implementation class AddUser1
 */
public class AddUser1 extends HttpServlet {
	static Logger logger=Logger.getLogger(UserDAOImpl.class);

	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddUser1() {
    	
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
UserBean u=new UserBean();
u.setUserName(request.getParameter("uname"));
u.setEmailId(request.getParameter("email"));
u.setAddress(request.getParameter("address"));
u.setPassWord(request.getParameter("pass"));
u.setMobileNo(Long.parseLong(request.getParameter("mobile")));
u.setQuestion(request.getParameter("question"));
u.setAnswer(request.getParameter("answer"));
UserDAOImpl ua=new UserDAOImpl();
String status=ua.AddUsers(u);
if(status.equals("Success"))
{request.setAttribute("message", "Account added succesfully");
	RequestDispatcher rd=request.getRequestDispatcher("signin.jsp");
	rd.forward(request, response);
	
}else{
	{request.setAttribute("message", "Account Not Added");
		RequestDispatcher rd=request.getRequestDispatcher("signup.jsp");
		rd.forward(request, response);
		
	}
}

      logger.info("User Type try to register account in the application:"+u.getUserName());
	
	}


}
