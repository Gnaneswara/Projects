package com.school.bean;

import java.io.Serializable;

public class UserBean implements Serializable {

	public int userId;
	public String userName;
	public String passWord;
	public int type;
	public String emailId;
	public long mobileNo;
	public String question;
	public String answer;
	public String address;

	public UserBean() {
		// TODO Auto-generated constructor stub
	}

	

	public int getType() {
		return type;
	}



	public void setType(int type) {
		this.type = type;
	}



	public UserBean(int userId, String userName, String passWord, int type, String emailId, long mobileNo,
			String question, String answer) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.passWord = passWord;
		this.type = type;
		this.emailId = emailId;
		this.mobileNo = mobileNo;
		this.question = question;
		this.answer = answer;
		this.address=address;
	}



	@Override
	public String toString() {
		return "UserBean [userId=" + userId + ", userName=" + userName + ", passWord=" + passWord + ", type=" + type
				+ ", emailId=" + emailId + ", mobileNo=" + mobileNo + ", question=" + question + ", answer=" + answer
				+ ", address=" + address + "]";
	}



	public String getAddress() {
		return address;
	}



	public void setAddress(String address) {
		this.address = address;
	}



	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassWord() {
		return passWord;
	}

	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}

	

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public long getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}


	}

	

