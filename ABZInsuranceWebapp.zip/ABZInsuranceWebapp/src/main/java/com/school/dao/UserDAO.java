package com.school.dao;


import java.util.ArrayList;

import com.school.bean.UserBean;

public interface UserDAO {
	
	public int login(UserBean u);
	public String fogot(UserBean u);
public String AddUsers(UserBean u);
ArrayList<UserBean> ViewallUsers();

}
